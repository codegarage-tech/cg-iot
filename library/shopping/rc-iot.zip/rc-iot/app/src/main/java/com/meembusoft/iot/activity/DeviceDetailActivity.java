package com.meembusoft.iot.activity;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;

import com.jaeger.library.StatusBarUtil;
import com.meembusoft.iot.R;
import com.meembusoft.iot.base.BaseLocationActivity;
import com.meembusoft.iot.model.MQTTDeviceStatus;
import com.meembusoft.retrofitmanager.APIResponse;
import com.meembusoft.iot.util.AppUtil;
import com.meembusoft.iot.util.Logger;
import com.rxmqtt.enums.ClientType;
import com.rxmqtt.exceptions.RxMqttException;
import com.rxmqtt.implementation.RxMqttClientFactory;
import com.rxmqtt.implementation.RxMqttClientStatus;
import com.rxmqtt.implementation.RxMqttMessage;
import com.rxmqtt.interfaces.IRxMqttClient;
import com.sdsmdg.harjot.crollerTest.Croller;
import com.sdsmdg.harjot.crollerTest.OnCrollerChangeListener;

import net.colindodd.toggleimagebutton.ToggleImageButton;

import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.json.JSONException;
import org.json.JSONObject;

import io.armcha.ribble.presentation.widget.AnimatedImageView;
import io.armcha.ribble.presentation.widget.AnimatedTextView;
import rx.Observer;
import rx.Subscriber;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class DeviceDetailActivity extends BaseLocationActivity {

    //Toolbar
    private AnimatedImageView leftMenu;
    private ImageView rightMenu;
    private AnimatedTextView toolbarTitle;

    private ToggleImageButton btnLight1, btnLight2, btnFan, btnSocket;
    private Croller crollerLight1, crollerFan;

    // MQTT
//    private IotMqttModel mqttModel;
    private String userId = "420", deviceId = "69", topic = "/420/69";
    private IRxMqttClient rxMqttClient;
    private String TAG_MQTT = ">>IRxMqttClient>>";

    @Override
    public String[] initActivityPermissions() {
        return new String[]{};
    }

    @Override
    public void onLocationFound(Location location) {
//        if (location != null) {
//
//            //Check internet connection
//            if (NetworkManager.isConnected(getActivity())) {
//                if (FragmentUtilsManager.getVisibleSupportFragment(HomeActivity.this, lastSelectedItem.getNavigationId().name()) instanceof CategoryWiseProductFragment) {
//                    //Request reverse geocoding for address
//                    if ((currentLocationTask != null) && (currentLocationTask.getStatus() == AsyncTask.Status.RUNNING)) {
//                        currentLocationTask.cancel(true);
//                    }
//
//                    currentLocationTask = new ReverseGeocoderTask(getActivity(), new LocationAddressListener() {
//                        @Override
//                        public void getLocationAddress(UserLocationAddress locationAddress) {
//                            if (locationAddress != null) {
//                                mLocationAddress = locationAddress;
//                                Logger.d(TAG, "UserLocationAddress: " + mLocationAddress.toString());
////                                        String addressText = String.format("%s, %s, %s, %s", locationAddress.getStreetAddress(), locationAddress.getCity(), locationAddress.getState(), locationAddress.getCountry());
//
//                                //Set address to the toolbar
//                                setToolBarTitle(mLocationAddress.getAddressLine());
//                            }
//                        }
//                    });
//                    currentLocationTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, location);
//                }
//            }
//        }
    }

    @Override
    public LOCATION_UPDATE_FREQUENCY initLocationUpdateFrequency() {
        return LOCATION_UPDATE_FREQUENCY.ONCE;
    }

    @Override
    public int initActivityLayout() {
        return R.layout.activity_device_detail_test;
    }

    @Override
    public void initStatusBarView() {
        StatusBarUtil.setTransparent(getActivity());
    }

    @Override
    public void initNavigationBarView() {

    }

    @Override
    public void initIntentData(Bundle savedInstanceState, Intent intent) {

    }

    @Override
    public void initActivityViews() {
        //toolbar view
        toolbarTitle = (AnimatedTextView) findViewById(R.id.toolbar_title);
        leftMenu = (AnimatedImageView) findViewById(R.id.left_menu);
        rightMenu = (ImageView) findViewById(R.id.right_menu);

        btnLight1 = (ToggleImageButton) findViewById(R.id.btn_light1);
        btnFan = (ToggleImageButton) findViewById(R.id.btn_fan);
        btnLight2 = (ToggleImageButton) findViewById(R.id.btn_light2);
        crollerLight1 = (Croller) findViewById(R.id.croller_light1);
        crollerFan = (Croller) findViewById(R.id.croller_fan);
        btnSocket = (ToggleImageButton) findViewById(R.id.btn_socket);
    }

    @Override
    public void initActivityViewsData(Bundle savedInstanceState) {
        setToolBarTitle(getString(R.string.title_activity_device_detail));
        initMQTT();
    }

    @Override
    public void initActivityActions(Bundle savedInstanceState) {
        leftMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initActivityBackPress();
            }
        });

        btnLight1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                MQTTDeviceStatus mqttDeviceStatus = new MQTTDeviceStatus((isChecked ? 1 : 0),
                        ((crollerLight1.getProgress() - 1) * 10),
                        (btnFan.isChecked() ? 1 : 0),
                        ((crollerFan.getProgress() - 1) * 10),
                        (btnLight2.isChecked() ? 1 : 0),
                        (btnSocket.isChecked() ? 1 : 0)
                );
                Logger.d(TAG, TAG_MQTT + ">>btnLight1>>onCheckedChanged>> mqttDeviceStatus: " + mqttDeviceStatus.toString());

                // Publish to topic
//                mqttModel.publishToTopic(mqttDeviceStatus);

                rxMqttClient.publish(topic, APIResponse.getJSONStringFromObject(mqttDeviceStatus).getBytes()).subscribe(new Observer<IMqttToken>() {
                    @Override
                    public void onCompleted() {
                        Logger.d(TAG, TAG_MQTT + "publish()>>onCompleted()");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Logger.d(TAG, TAG_MQTT + "publish()>>onError()>> e: " + e.getMessage());
                    }

                    @Override
                    public void onNext(IMqttToken iMqttToken) {
                        try {
                            Logger.d(TAG, TAG_MQTT + "publish()>>onNext()>>iMqttToken: " + new String(iMqttToken.getResponse().getPayload(), "UTF-8"));
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                });

            }
        });

        crollerLight1.setOnCrollerChangeListener(new OnCrollerChangeListener() {
            @Override
            public void onProgressChanged(Croller croller, int progress) {
                croller.setLabel(((progress - 1) * 10) + "%");
            }

            @Override
            public void onStartTrackingTouch(Croller croller) {
            }

            @Override
            public void onStopTrackingTouch(Croller croller) {
            }
        });

        crollerFan.setOnCrollerChangeListener(new OnCrollerChangeListener() {
            @Override
            public void onProgressChanged(Croller croller, int progress) {
                croller.setLabel(((progress - 1) * 10) + "%");
            }

            @Override
            public void onStartTrackingTouch(Croller croller) {
            }

            @Override
            public void onStopTrackingTouch(Croller croller) {
            }
        });
    }

    @Override
    public void initActivityOnResult(int requestCode, int resultCode, Intent data) {

    }

    @Override
    public void initActivityBackPress() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            finish();
        }
    }

    @Override
    public void initActivityDestroyTasks() {
        dismissProgressDialog();

//        if (mqttModel != null) {
//            mqttModel.disconnect(getActivity());
//        }

        // Disconnect
        rxMqttClient.disconnect().subscribe(new Observer<IMqttToken>() {
            @Override
            public void onCompleted() {
                Logger.d(TAG, TAG_MQTT + "disconnect()>>onCompleted()");
            }

            @Override
            public void onError(Throwable e) {
                Logger.d(TAG, TAG_MQTT + "disconnect()>>onError()>> e: " + e.getMessage());
            }

            @Override
            public void onNext(IMqttToken iMqttToken) {
                try {
                    Logger.d(TAG, TAG_MQTT + "disconnect()>>onNext()>>iMqttToken: " + new String(iMqttToken.getResponse().getPayload(), "UTF-8"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    @Override
    public void initActivityPermissionResult(int requestCode, String[] permissions, int[] grantResults) {

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void setToolBarTitle(String title) {
        toolbarTitle.setAnimatedText(title, 0L);

        //For marquee address
        AppUtil.applyMarqueeOnTextView(toolbarTitle);
    }

    /***************
     * MQTT methods *
     ****************/
    @Override
    protected void onStart() {
        super.onStart();
//        mqttModel.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
//        mqttModel.stop();
    }

    private void initMQTT() {
        try {
            // Create IRxMqttClient
            rxMqttClient = new RxMqttClientFactory().create(
                    "157.245.88.4",
                    1883,
                    getClientID(),
                    false,
                    ClientType.Async);

            // Subscribe for Status report
            rxMqttClient.statusReport().subscribe(new Observer<RxMqttClientStatus>() {
                @Override
                public void onCompleted() {
                    Logger.d(TAG, TAG_MQTT + "statusReport()>>onCompleted()");
                }

                @Override
                public void onError(Throwable e) {
                    Logger.d(TAG, TAG_MQTT + "statusReport()>>onError()>> e: " + e.getMessage());
                }

                @Override
                public void onNext(RxMqttClientStatus rxMqttClientStatus) {
                    try {
                        Logger.d(TAG, TAG_MQTT + "statusReport()>>onNext()>>rxMqttClientStatus: " + rxMqttClientStatus.toString());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });

            // Connect to MQTT
            rxMqttClient.connect().subscribe(new Subscriber<IMqttToken>() {
                @Override
                public void onCompleted() {
                    Logger.d(TAG, TAG_MQTT + "connect()>>onCompleted()");
                }

                @Override
                public void onError(Throwable e) {
                    Logger.d(TAG, TAG_MQTT + "connect()>>onError()>> e: " + e.getMessage());
                }

                @Override
                public void onNext(IMqttToken iMqttToken) {
                    try {
                        Logger.d(TAG, TAG_MQTT + "connect()>>onNext()>>iMqttToken: " + new String(iMqttToken.getResponse().getPayload(), "UTF-8"));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });

            // Subscribe to topic
            rxMqttClient.subscribeTopic(topic, 1/*QoS*/).subscribe(new Observer<RxMqttMessage>() {
                @Override
                public void onCompleted() {
                    Logger.d(TAG, TAG_MQTT + "subscribeTopic()>>onCompleted()");
                }

                @Override
                public void onError(Throwable e) {
                    Logger.d(TAG, TAG_MQTT + "subscribeTopic()>>onError()>> e: " + e.getMessage());
                }

                @Override
                public void onNext(RxMqttMessage rxMqttMessage) {
                    try {
                        Logger.d(TAG, TAG_MQTT + "subscribeTopic()>>onNext()>>rxMqttMessage: " + rxMqttMessage.getMessage());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
        } catch (RxMqttException ex) {
            ex.printStackTrace();
        }

//        mqttModel = new IotMqttModel(getActivity(), userId, deviceId);
//        mqttModel.setCallback(new IotMqttModel.Callback() {
//            @Override
//            public void onConnectionChanged(String connection) {
//
//            }
//
//            @Override
//            public void onTopicChanged(Object object) {
//                Logger.d(TAG, TAG + ">>initMQTT>>onTopicChanged>> object: " + toPrettyJsonString(object.toString()));
//            }
//        });
//        mqttModel.connect(getActivity(),
//                getServerURL(),
//                getClientID(),
//                getUserName(),
//                getPassword());
//        mqttModel.subscribeToTopic();
    }

    private String toPrettyJsonString(String jsonStr) {
        String result = jsonStr;
        try {
            JSONObject json = new JSONObject(jsonStr);
            result = json.toString(4);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

    public String getServerURL() {
        String scheme = "tcp://";
        String host = "157.245.88.4";
        int port = 1883;
        return scheme + host + ":" + port;
    }

    public String getClientID() {
        return userId + "." + deviceId;
    }

    public String getUserName() {
        return "admin";
    }

    public String getPassword() {
        return "admin";
    }
}