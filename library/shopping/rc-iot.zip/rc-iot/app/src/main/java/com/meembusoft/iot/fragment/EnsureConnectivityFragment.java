package com.meembusoft.iot.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.reversecoder.library.util.AllSettingsManager;

import com.meembusoft.iot.R;
import com.meembusoft.iot.base.BaseFragment;
import com.meembusoft.iot.enumeration.ConnectionType;
import com.meembusoft.iot.util.SessionUtil;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class EnsureConnectivityFragment extends BaseFragment {

//    private FlowLayout flowLayoutConnectionType;
//    private FlowLayoutManager flowLayoutManagerConnectionType;
    private LinearLayout llWifi, llBluetooth, llMobileData;

    public static EnsureConnectivityFragment newInstance() {
        EnsureConnectivityFragment fragment = new EnsureConnectivityFragment();
        return fragment;
    }

    @Override
    public int initFragmentLayout() {
        return R.layout.fragment_ensure_connectivity;
    }

    @Override
    public void initFragmentBundleData(Bundle bundle) {
    }

    @Override
    public void initFragmentViews(View parentView) {
//        flowLayoutConnectionType = (FlowLayout) parentView.findViewById(R.id.fl_connection_type);

        llWifi = (LinearLayout) parentView.findViewById(R.id.ll_wifi);
        llBluetooth = (LinearLayout) parentView.findViewById(R.id.ll_bluetooth);
        llMobileData = (LinearLayout) parentView.findViewById(R.id.ll_mobile_data);
    }

    @Override
    public void initFragmentViewsData() {
//        Product tempChosenDevice = SessionUtil.getTempChosenDevice(getActivity());
//        if (tempChosenDevice != null) {
//            initConnectionType(tempChosenDevice);
//        }


    }

    @Override
    public void initFragmentActions() {

    }

    @Override
    public void initFragmentBackPress() {

    }

    @Override
    public void initFragmentOnResult(int requestCode, int resultCode, Intent data) {

    }

    @Override
    public void initFragmentUpdate(Object object) {

    }

    /***************************
     * Methods for flow layout *
     ***************************/
//    public void initConnectionType(final Product device) {
//        if (device != null) {
//            //Set flow layout with connection key
//            flowLayoutManagerConnectionType = new FlowLayoutManager.FlowViewBuilder(getActivity(), flowLayoutConnectionType, device.getConnection_type(), new FlowLayoutManager.onFlowViewClick() {
//                @Override
//                public void flowViewClick(TextView updatedTextView) {
//                    List<TextView> selectedConnectionTypeKeys = flowLayoutManagerConnectionType.getSelectedFlowViews();
//                    String tempSelectedConnection = (selectedConnectionTypeKeys.size() > 0) ? selectedConnectionTypeKeys.get(0).getText().toString() : "";
//                    Logger.d(TAG, "tempSelectedConnection: " + tempSelectedConnection);
//
//                    //Save temp selected connection type
//                    device.setSelected_connection(tempSelectedConnection);
//                    SessionUtil.setTempSelectedConnectionType(getActivity(), tempSelectedConnection);
//                }
//            })
//                    .setSingleChoice(true)
//                    .build();
//
//            //Set last temp selected connection type key
//            String lastTempSelectedRoom = SessionUtil.getTempSelectedConnectionType(getActivity());
//            if (!AllSettingsManager.isNullOrEmpty(lastTempSelectedRoom)) {
//                flowLayoutManagerConnectionType.clickFlowView(lastTempSelectedRoom);
//            }
//        }
//    }

    private void selectConnectionType(ConnectionType connectionType){
        if(connectionType !=null){
            switch (connectionType){
                case WIFI:
                    break;
                case BLUETOOTH:
                    break;
                case MOBILE_DATA:
                    break;
            }
        }
    }

    public boolean isAllFieldsVerified() {
        String lastTempSelectedConnectionType = SessionUtil.getTempSelectedConnectionType(getActivity());
        if (!AllSettingsManager.isNullOrEmpty(lastTempSelectedConnectionType)) {
            return true;
        } else {
            Toast.makeText(getActivity(), getString(R.string.txt_please_select_your_connection_type), Toast.LENGTH_SHORT).show();
        }

        return false;
    }
}