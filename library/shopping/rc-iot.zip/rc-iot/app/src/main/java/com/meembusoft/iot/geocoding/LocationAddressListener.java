package com.meembusoft.iot.geocoding;

/**
 * @author Md. Rashadul Alam
 *         Email: rashed.droid@gmail.com
 */
public interface LocationAddressListener {
    public void getLocationAddress(UserLocationAddress locationAddress);
}
