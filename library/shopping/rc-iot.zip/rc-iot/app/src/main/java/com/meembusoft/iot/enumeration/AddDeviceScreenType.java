package com.meembusoft.iot.enumeration;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public enum AddDeviceScreenType {
    SELECT_ROOM, CHOOSE_DEVICE, ATTACH_APPLIANCE, ENSURE_CONNECTIVITY, CONNECT_DEVICE, PREVIEW_SCREEN;
}