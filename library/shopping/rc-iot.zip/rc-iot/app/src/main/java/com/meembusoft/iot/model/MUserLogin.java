//package com.meembusoft.iot.model;
//
///**
// * @author Md. Rashadul Alam
// * Email: rashed.droid@gmail.com
// */
//public class MUserLogin {
//
//    private String phone = "";
//    private String password = "";
//
//
//    public MUserLogin() {
//    }
//
//    public MUserLogin(String phone, String password) {
//        this.phone = phone;
//        this.password = password;
//    }
//
//
//    public String getPhone() {
//        return phone;
//    }
//
//    public void setPhone(String phone) {
//        this.phone = phone;
//    }
//
//    @Override
//    public String toString() {
//        return "MParamUserLogin{" +
//                "phone='" + phone + '\'' +
//                ", password='" + password + '\'' +
//                '}';
//    }
//}