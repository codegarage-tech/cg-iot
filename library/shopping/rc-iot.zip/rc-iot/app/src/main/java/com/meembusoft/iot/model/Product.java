package com.meembusoft.iot.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class Product {

    private String product_id = "";
    private String product_qr_code = "";
    private String product_name = "";
    private List<Image> product_images = new ArrayList<>();
    private double product_price = 0;
    private String product_description = "";
    private double product_discount_percentage = 0;
    private List<Color> product_colors = new ArrayList<>();
    private List<Size> product_sizes = new ArrayList<>();
    private List<ConnectionType> product_connection_types = new ArrayList<>();
    private List<CommunicationType> product_communication_types = new ArrayList<>();
    private List<Subscription> product_subscriptions = new ArrayList<>();
    /*This is for local usage*/
    private boolean isSelected = false;

    public Product() {
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_qr_code() {
        return product_qr_code;
    }

    public void setProduct_qr_code(String product_qr_code) {
        this.product_qr_code = product_qr_code;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public List<Image> getProduct_images() {
        return product_images;
    }

    public void setProduct_images(List<Image> product_images) {
        this.product_images = product_images;
    }

    public double getProduct_price() {
        return product_price;
    }

    public void setProduct_price(double product_price) {
        this.product_price = product_price;
    }

    public String getProduct_description() {
        return product_description;
    }

    public void setProduct_description(String product_description) {
        this.product_description = product_description;
    }

    public double getProduct_discount_percentage() {
        return product_discount_percentage;
    }

    public void setProduct_discount_percentage(double product_discount_percentage) {
        this.product_discount_percentage = product_discount_percentage;
    }

    public List<Color> getProduct_colors() {
        return product_colors;
    }

    public void setProduct_colors(List<Color> product_colors) {
        this.product_colors = product_colors;
    }

    public List<Size> getProduct_sizes() {
        return product_sizes;
    }

    public void setProduct_sizes(List<Size> product_sizes) {
        this.product_sizes = product_sizes;
    }

    public List<ConnectionType> getProduct_connection_types() {
        return product_connection_types;
    }

    public void setProduct_connection_types(List<ConnectionType> product_connection_types) {
        this.product_connection_types = product_connection_types;
    }

    public List<CommunicationType> getProduct_communication_types() {
        return product_communication_types;
    }

    public void setProduct_communication_types(List<CommunicationType> product_communication_types) {
        this.product_communication_types = product_communication_types;
    }

    public List<Subscription> getProduct_subscriptions() {
        return product_subscriptions;
    }

    public void setProduct_subscriptions(List<Subscription> product_subscriptions) {
        this.product_subscriptions = product_subscriptions;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    @Override
    public String toString() {
        return "{" +
                "product_id='" + product_id + '\'' +
                ", product_qr_code='" + product_qr_code + '\'' +
                ", product_name='" + product_name + '\'' +
                ", product_images=" + product_images +
                ", product_price=" + product_price +
                ", product_description='" + product_description + '\'' +
                ", product_discount_percentage=" + product_discount_percentage +
                ", product_colors=" + product_colors +
                ", product_sizes=" + product_sizes +
                ", product_connection_types=" + product_connection_types +
                ", product_communication_types=" + product_communication_types +
                ", product_subscriptions=" + product_subscriptions +
                ", isSelected=" + isSelected +
                '}';
    }
}