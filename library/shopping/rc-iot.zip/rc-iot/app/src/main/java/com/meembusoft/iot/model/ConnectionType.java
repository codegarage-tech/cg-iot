package com.meembusoft.iot.model;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class ConnectionType {

    private String id = "";
    private String connection_name = "";

    public ConnectionType() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConnection_name() {
        return connection_name;
    }

    public void setConnection_name(String connection_name) {
        this.connection_name = connection_name;
    }

    @Override
    public String toString() {
        return "{" +
                "id='" + id + '\'' +
                ", connection_name='" + connection_name + '\'' +
                '}';
    }
}