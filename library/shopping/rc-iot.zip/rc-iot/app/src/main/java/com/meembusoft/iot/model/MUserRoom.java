//package com.meembusoft.iot.model;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * @author Md. Rashadul Alam
// * Email: rashed.droid@gmail.com
// */
//public class MUserRoom {
//
//    private String user_room_id = "";
//    private String room = "";
//    private List<MDevices> devices = new ArrayList<>();
//
//    public MUserRoom() {
//    }
//
//
//    public String getUser_room_id() {
//        return user_room_id;
//    }
//
//    public void setUser_room_id(String user_room_id) {
//        this.user_room_id = user_room_id;
//    }
//
//    public String getRoom() {
//        return room;
//    }
//
//    public void setRoom(String room) {
//        this.room = room;
//    }
//
//    public List<MDevices> getDevices() {
//        return devices;
//    }
//
//    public void setDevices(List<MDevices> devices) {
//        this.devices = devices;
//    }
//
//    @Override
//    public String toString() {
//        return "MUserRoom{" +
//                "user_room_id='" + user_room_id + '\'' +
//                ", room='" + room + '\'' +
//                ", devices=" + devices +
//                '}';
//    }
//}