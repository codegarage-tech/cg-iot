package com.meembusoft.iot.base;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public interface BaseUpdateListener {

    public void onUpdate(Object... update);
}