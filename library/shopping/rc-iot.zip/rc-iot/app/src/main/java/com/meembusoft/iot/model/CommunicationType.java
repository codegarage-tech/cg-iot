package com.meembusoft.iot.model;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class CommunicationType {

    private String id = "";
    private String communication_name = "";

    public CommunicationType() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCommunication_name() {
        return communication_name;
    }

    public void setCommunication_name(String communication_name) {
        this.communication_name = communication_name;
    }

    @Override
    public String toString() {
        return "{" +
                "id='" + id + '\'' +
                ", communication_name='" + communication_name + '\'' +
                '}';
    }
}