package com.meembusoft.iot.interfaces;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public interface OnFragmentUpdateListener {
    public void onFragmentUpdate(Object update);
}