package com.meembusoft.iot.model;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class Subscription {

    private String id = "";
    private String subscription_name = "";
    private String subscription_price = "";
    private String subscription_description = "";

    public Subscription() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSubscription_name() {
        return subscription_name;
    }

    public void setSubscription_name(String subscription_name) {
        this.subscription_name = subscription_name;
    }

    public String getSubscription_price() {
        return subscription_price;
    }

    public void setSubscription_price(String subscription_price) {
        this.subscription_price = subscription_price;
    }

    public String getSubscription_description() {
        return subscription_description;
    }

    public void setSubscription_description(String subscription_description) {
        this.subscription_description = subscription_description;
    }

    @Override
    public String toString() {
        return "{" +
                "id='" + id + '\'' +
                ", subscription_name='" + subscription_name + '\'' +
                ", subscription_price='" + subscription_price + '\'' +
                ", subscription_description='" + subscription_description + '\'' +
                '}';
    }
}