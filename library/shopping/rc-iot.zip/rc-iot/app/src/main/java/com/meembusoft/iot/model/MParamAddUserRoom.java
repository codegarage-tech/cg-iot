//package com.meembusoft.iot.model;
//
///**
// * @author Md. Rashadul Alam
// * Email: rashed.droid@gmail.com
// */
//public class MParamAddUserRoom {
//
//    private String user_id = "";
//    private String room = "";
//    private String id = "";
//
//    public MParamAddUserRoom() {
//    }
//
//    public MParamAddUserRoom(String user_id, String room, String id) {
//        this.user_id = user_id;
//        this.room = room;
//        this.id = id;
//    }
//
//    public String getUser_id() {
//        return user_id;
//    }
//
//    public void setUser_id(String user_id) {
//        this.user_id = user_id;
//    }
//
//    public String getRoom() {
//        return room;
//    }
//
//    public void setRoom(String room) {
//        this.room = room;
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//
//    @Override
//    public String toString() {
//        return "MParamAddUserRoom{" +
//                "user_id='" + user_id + '\'' +
//                ", room='" + room + '\'' +
//                ", id='" + id + '\'' +
//                '}';
//    }
//}