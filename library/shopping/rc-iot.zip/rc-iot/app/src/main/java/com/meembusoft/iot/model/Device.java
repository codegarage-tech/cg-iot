package com.meembusoft.iot.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public class Device {

    private Product product;
    private Color device_color;
    private Size device_size;
    private ConnectionType device_connection_type ;
    private CommunicationType device_communication_type;
    private Subscription device_subscription;
    private int is_favorite;

    public Device() {
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Color getDevice_color() {
        return device_color;
    }

    public void setDevice_color(Color device_color) {
        this.device_color = device_color;
    }

    public Size getDevice_size() {
        return device_size;
    }

    public void setDevice_size(Size device_size) {
        this.device_size = device_size;
    }

    public ConnectionType getDevice_connection_type() {
        return device_connection_type;
    }

    public void setDevice_connection_type(ConnectionType device_connection_type) {
        this.device_connection_type = device_connection_type;
    }

    public CommunicationType getDevice_communication_type() {
        return device_communication_type;
    }

    public void setDevice_communication_type(CommunicationType device_communication_type) {
        this.device_communication_type = device_communication_type;
    }

    public Subscription getDevice_subscription() {
        return device_subscription;
    }

    public void setDevice_subscription(Subscription device_subscription) {
        this.device_subscription = device_subscription;
    }

    public int getIs_favorite() {
        return is_favorite;
    }

    public void setIs_favorite(int is_favorite) {
        this.is_favorite = is_favorite;
    }

    @Override
    public String toString() {
        return "{" +
                "product=" + product +
                ", device_color=" + device_color +
                ", device_size=" + device_size +
                ", device_connection_type=" + device_connection_type +
                ", device_communication_type=" + device_communication_type +
                ", device_subscription=" + device_subscription +
                ", is_favorite=" + is_favorite +
                '}';
    }
}