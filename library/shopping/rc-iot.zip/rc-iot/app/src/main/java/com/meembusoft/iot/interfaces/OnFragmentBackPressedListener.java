package com.meembusoft.iot.interfaces;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public interface OnFragmentBackPressedListener {
    public void onFragmentBackPressed();
}