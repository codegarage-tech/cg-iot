package com.meembusoft.iot.enumeration;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public enum DeviceType {

    SWITCH_BOARD_WIFI_CONTROLLED("Smart Home V1"),
    MOTOR_SINGLE_WIFI_CONTROLLED_WITHOUT_WATER_LEVEL("Smart motor V1"),
    MOTOR_SINGLE_WIFI_CONTROLLED_WITH_WATER_LEVEL("Smart motor V2"),
    MOTOR_DOUBLE_WIFI_CONTROLLED_WITHOUT_WATER_LEVEL("Smart motor V3"),
    MOTOR_DOUBLE_WIFI_CONTROLLED_WITH_WATER_LEVEL("Smart motor V4");

    private final String deviceType;

    private DeviceType(String value) {
        deviceType = value;
    }

    public boolean equalsName(String otherName) {
        return deviceType.equals(otherName);
    }

    public String getValue() {
        return this.deviceType;
    }

    public static DeviceType getDeviceType(String value) {
        for (DeviceType deviceType : DeviceType.values()) {
            if (deviceType.getValue().equalsIgnoreCase(value)) {
                return deviceType;
            }
        }
        return null;
    }
}