//package com.meembusoft.iot.model;
//
///**
// * @author Md. Rashadul Alam
// * Email: rashed.droid@gmail.com
// */
//public class MAddUserRoom {
//
//    private String id = "";
//    private String user_room_id = "";
//    private String room = "";
//
//    public MAddUserRoom() {
//    }
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public String getUser_room_id() {
//        return user_room_id;
//    }
//
//    public void setUser_room_id(String user_room_id) {
//        this.user_room_id = user_room_id;
//    }
//
//    public String getRoom() {
//        return room;
//    }
//
//    public void setRoom(String room) {
//        this.room = room;
//    }
//
//    @Override
//    public String toString() {
//        return "MAddUserRoom{" +
//                "id='" + id + '\'' +
//                ", user_room_id='" + user_room_id + '\'' +
//                ", room='" + room + '\'' +
//                '}';
//    }
//}