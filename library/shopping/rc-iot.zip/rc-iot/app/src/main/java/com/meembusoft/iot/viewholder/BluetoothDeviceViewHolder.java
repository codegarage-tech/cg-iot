package com.meembusoft.iot.viewholder;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.jude.easyrecyclerview.adapter.BaseViewHolder;
import com.reversecoder.library.event.OnSingleClickListener;

import com.meembusoft.iot.R;
import com.meembusoft.iot.base.BaseUpdateListener;
import com.meembusoft.iot.bluetooth.BTSendRec;
import com.meembusoft.iot.bluetooth.BluetoothHandler;
import com.meembusoft.iot.bluetooth.PairRunnable;
import com.meembusoft.iot.bluetooth.UnpairRunnable;
import com.meembusoft.iot.util.Logger;


public class BluetoothDeviceViewHolder extends BaseViewHolder<BluetoothDevice> {

    private String TAG = BluetoothDeviceViewHolder.class.getSimpleName();
    private TextView tvDeviceName, tvDeviceAddress, tvDevicePairStatus;
    private Button btnPairDevice, btnConnect, btnLight;

    private static final int MAX_NAME_CHECKS = 3;
    private static final int NAME_CHECK_PERIOD = 1000;
    private int nameChecks;
    private Context mContext;

    private String lastSent = "";
    private BTSendRec btsendrec;

    public BluetoothDeviceViewHolder(ViewGroup parent, Context context) {
        super(parent, R.layout.row_bluetooth_device);
        mContext = context;

        tvDeviceName = $(R.id.tv_name);
        tvDeviceAddress = $(R.id.tv_address);
        tvDevicePairStatus = $(R.id.tv_pair_status);
        btnPairDevice = $(R.id.btn_pair);
        btnConnect = $(R.id.btn_connect);
        btnLight = $(R.id.btn_light);
    }

    @Override
    public void setData(final BluetoothDevice data) {

//        tvDeviceName.setText(data.getName());
        resolveName(data, tvDeviceName, mContext);
        tvDeviceAddress.setText(data.getAddress());
        tvDevicePairStatus.setText((data.getBondState() == BluetoothDevice.BOND_BONDED) ? "Paired" : "Unpaired");

        if ((data.getBondState() == BluetoothDevice.BOND_BONDED)) {
            btnPairDevice.setText("Unpair");
        } else {
            btnPairDevice.setText("Pair");
        }

        if (BluetoothHandler.getInstance().getBluetoothSocket() == null) {
            btnConnect.setText("Connect");
        } else {
            btnConnect.setText("Disconnect");
        }

        if (TextUtils.isEmpty(lastSent) || lastSent.equalsIgnoreCase("0")) {
            btnLight.setText("On");
        } else{
            btnLight.setText("Off");
        }

        btnPairDevice.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View view) {
                try {
                    Logger.d(TAG, "btnPairDevice>>setOnClickListener>> data: " + data.toString());
//                    ((BluetoothActivity)mContext).showProgressDialog();
                    if ((data.getBondState() != BluetoothDevice.BOND_BONDED)) {
                        Thread mPairThread = new Thread(new PairRunnable(data));
                        mPairThread.start();
                    } else {
                        Thread mUnpairThread = new Thread(new UnpairRunnable(data));
                        mUnpairThread.start();
                    }
                } catch (Exception e) {
                    Logger.d(TAG, "btnPairDevice>>setOnClickListener>> exception: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });

        btnConnect.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View view) {
                try {
                    if (BluetoothHandler.getInstance().getBluetoothSocket() == null) {
                        Logger.d(TAG, "btnConnect>>setOnClickListener>> data: " + data.toString());
                        BluetoothHandler.getInstance().startBluetoothConnectionTask(mContext, data, new BaseUpdateListener() {
                            @Override
                            public void onUpdate(Object... update) {
                                Object data = update[0];
                                if (data != null) {
                                    boolean isConnected = (boolean) data;
                                    if (isConnected) {
                                        btsendrec = new BTSendRec(BluetoothHandler.getInstance().getBluetoothSocket(), mHandler);
                                        btsendrec.start();
                                    }
                                }
                            }
                        });
                    } else {
                        BluetoothHandler.getInstance().stopBluetoothConnection();
                    }

                    getOwnerAdapter().notifyDataSetChanged();
                } catch (Exception e) {
                    Logger.d(TAG, "btnConnect>>setOnClickListener>> exception: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });

        btnLight.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View view) {
                try {
                    if (TextUtils.isEmpty(lastSent) || lastSent.equalsIgnoreCase("0")) {
                        btsendrec.Send("1");
                        lastSent = "1";
                    } else {
                        btsendrec.Send("0");
                        lastSent = "0";
                    }
                    getOwnerAdapter().notifyDataSetChanged();
                } catch (Exception e) {
                    Logger.d(TAG, "btnLight>>setOnClickListener>> exception: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }

    /* Define a Handler to transfer data from the thread in which send and
     * receive is done. and then perform some action on received data, in this case the room temperature.
     */
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

            switch (msg.what) {

                case BTSendRec.READ_SUCCESS:

                    byte[] writeBuf = (byte[]) msg.obj;
                    int begin = (int) msg.arg1;
                    int end = (int) msg.arg2;

//                    String RoomTemp = new String(writeBuf);
//                    RoomTemp = RoomTemp.substring(begin, end);
//
//                    RoomTempText.setText(RoomTemp + " C");
                    break;
            }
        }
    };

    /**
     * Checks for the device name, for a maximum of {@link BluetoothDeviceViewHolder#MAX_NAME_CHECKS}
     * as the name may not have been resolved at binding.
     */
    private void resolveName(final BluetoothDevice device, final TextView deviceName, final Context context) {
        if (device != null) {
            String name = device.getName();
            boolean isEmptyName = TextUtils.isEmpty(name);

            if (isEmptyName) deviceName.setText(R.string.txt_unknown_device);
            else deviceName.setText(name);

            // Check later if device name is resolved
            if (nameChecks++ < MAX_NAME_CHECKS && isEmptyName)
                itemView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        resolveName(device, deviceName, context);
                    }
                }, NAME_CHECK_PERIOD);
        }
    }
}