package com.reversecoder.attributionpresenter.util;

/**
 * @author Md. Rashadul Alam
 *         Email: rashed.droid@gmail.com
 */
public class Constants {

    //Intent key
    public static final String INTENT_KEY_ATTRIBUTION = "INTENT_KEY_ATTRIBUTION";
}
