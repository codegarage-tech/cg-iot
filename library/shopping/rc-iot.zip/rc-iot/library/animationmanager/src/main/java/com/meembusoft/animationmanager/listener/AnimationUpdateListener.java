package com.meembusoft.animationmanager.listener;

/**
 * @author Md. Rashadul Alam
 * Email: rashed.droid@gmail.com
 */
public interface AnimationUpdateListener {

    public void onUpdate(Object... update);
}