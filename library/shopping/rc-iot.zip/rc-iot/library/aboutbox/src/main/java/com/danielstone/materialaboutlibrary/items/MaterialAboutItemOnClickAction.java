package com.danielstone.materialaboutlibrary.items;

public interface MaterialAboutItemOnClickAction {
    void onClick();
}
