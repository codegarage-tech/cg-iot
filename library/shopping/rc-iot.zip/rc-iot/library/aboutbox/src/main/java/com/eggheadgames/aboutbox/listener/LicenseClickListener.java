package com.eggheadgames.aboutbox.listener;

public interface LicenseClickListener {
    public void onLicenseClick();
}