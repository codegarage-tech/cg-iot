package com.eggheadgames.aboutbox;


import android.app.Activity;

public interface IShare {

    void share(Activity activity);
}
