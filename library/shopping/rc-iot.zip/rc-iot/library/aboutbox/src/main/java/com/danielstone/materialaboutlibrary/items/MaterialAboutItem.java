package com.danielstone.materialaboutlibrary.items;


public abstract class MaterialAboutItem {

    public abstract int getType();

}
