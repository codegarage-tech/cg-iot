package com.danielstone.materialaboutlibrary.holders;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public abstract class MaterialAboutItemViewHolder extends RecyclerView.ViewHolder {

    public MaterialAboutItemViewHolder(View itemView) {
        super(itemView);
    }

}
